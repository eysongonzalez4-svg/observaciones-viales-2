# Instalación privada de Observador Vial

## 1. Crear la base privada

1. Cree una hoja de Google llamada **Base Observador Vial**.
2. No la comparta con los conductores.
3. Copie el identificador entre `/d/` y `/edit` en la dirección de la hoja.
4. Abra **Extensiones > Apps Script**.
5. Pegue el contenido de `Code.gs`.
6. Reemplace `PEGUE_AQUI_EL_ID_DE_SU_HOJA`.
7. Ejecute `prepararHojas` una vez y autorice.

## 2. Publicar el receptor

1. En Apps Script seleccione **Implementar > Nueva implementación**.
2. Tipo: **Aplicación web**.
3. Ejecutar como: **usted**.
4. Seleccione el acceso que permita recibir envíos desde los teléfonos.
5. Copie la URL terminada en `/exec`.
6. Abra `config.js` y reemplace `PEGUE_AQUI_LA_URL_DEL_SCRIPT`.
7. Cambie `Mi empresa` por el nombre de su organización.

La hoja permanece privada en su Google Drive. Los conductores solo envían datos.

## 3. Convertirla en aplicación

1. Publique los archivos web gratuitamente en GitHub Pages.
2. Abra la URL HTTPS en Chrome desde cada teléfono.
3. Use **Menú > Agregar a pantalla principal > Instalar**.
4. Quedará un ícono llamado **Observador Vial**.

## 4. Excel solo para el administrador

Usted abre la hoja privada y, cuando necesite un Excel, usa:

**Archivo > Descargar > Microsoft Excel (.xlsx)**

## Limitaciones

- La aplicación necesita internet al enviar.
- Si falla, guarda temporalmente el recorrido en el teléfono para reintentar.
- El GPS web puede detenerse si el teléfono bloquea la pantalla.
- La hoja no es pública, pero esta versión gratuita no incluye autenticación individual.
- Para datos sensibles o una flota grande conviene una solución con usuarios y control de acceso.
