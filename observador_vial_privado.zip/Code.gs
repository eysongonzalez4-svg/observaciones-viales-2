const SPREADSHEET_ID = "PEGUE_AQUI_EL_ID_DE_SU_HOJA";

function doGet() {
  return ContentService.createTextOutput(
    JSON.stringify({ok:true, service:"Observador Vial"})
  ).setMimeType(ContentService.MimeType.JSON);
}

function doPost(e) {
  const lock = LockService.getScriptLock();
  lock.waitLock(30000);
  try {
    const data = JSON.parse(e.postData.contents);
    if (data.action !== "saveTrip" || !data.trip) throw new Error("Solicitud no válida");
    prepararHojas();
    guardarRecorrido_(data.trip, data.organization || "");
    return ContentService.createTextOutput(JSON.stringify({ok:true}))
      .setMimeType(ContentService.MimeType.JSON);
  } catch (error) {
    return ContentService.createTextOutput(JSON.stringify({ok:false,error:String(error)}))
      .setMimeType(ContentService.MimeType.JSON);
  } finally {
    lock.releaseLock();
  }
}

function prepararHojas() {
  const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
  crearHoja_(ss, "Recorridos", [
    "ID recorrido","Organización","Conductor","Vehículo","Origen","Destino",
    "Inicio","Finalización","Duración (min)","Distancia aproximada (km)",
    "Cantidad de peligros","Resultado","Fecha de recepción"
  ]);
  crearHoja_(ss, "Peligros", [
    "ID peligro","ID recorrido","Conductor","Vehículo","Origen","Destino",
    "Fecha del recorrido","Fecha del reporte","Tipo de peligro","Nivel de riesgo",
    "Punto de referencia","Latitud","Longitud"
  ]);
  crearHoja_(ss, "Puntos GPS", [
    "ID recorrido","Conductor","Vehículo","Número de punto",
    "Fecha y hora GPS","Latitud","Longitud","Precisión aproximada (m)"
  ]);
}

function guardarRecorrido_(trip, organization) {
  const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
  const recorridos = ss.getSheetByName("Recorridos");
  const peligros = ss.getSheetByName("Peligros");
  const puntos = ss.getSheetByName("Puntos GPS");

  const ids = recorridos.getLastRow() > 1
    ? recorridos.getRange(2,1,recorridos.getLastRow()-1,1).getValues().flat()
    : [];
  if (ids.includes(trip.id)) return;

  const route = trip.route || [];
  const hazards = trip.hazards || [];
  const durationMin = trip.startedAt && trip.endedAt
    ? Math.max(1, Math.round((new Date(trip.endedAt)-new Date(trip.startedAt))/60000))
    : "";
  const result = hazards.length
    ? "Con peligros reportados"
    : (trip.noHazardsObserved ? "Sin peligros observados" : "Sin confirmación");

  recorridos.appendRow([
    trip.id, organization, trip.driver, trip.vehicle, trip.origin, trip.destination,
    fecha_(trip.startedAt), fecha_(trip.endedAt), durationMin,
    calcularDistanciaKm_(route), hazards.length, result, new Date()
  ]);

  if (hazards.length) {
    const rows = hazards.map(h => [
      h.id, trip.id, trip.driver, trip.vehicle, trip.origin, trip.destination,
      fecha_(trip.startedAt), fecha_(h.reportedAt), h.type, h.risk,
      h.reference || "", h.lat, h.lng
    ]);
    peligros.getRange(peligros.getLastRow()+1,1,rows.length,rows[0].length).setValues(rows);
  }

  if (route.length) {
    const rows = route.map((p,i) => [
      trip.id, trip.driver, trip.vehicle, i+1,
      fecha_(p.timestamp), p.lat, p.lng, p.accuracy
    ]);
    puntos.getRange(puntos.getLastRow()+1,1,rows.length,rows[0].length).setValues(rows);
  }
}

function crearHoja_(ss, name, headers) {
  let sheet = ss.getSheetByName(name);
  if (!sheet) sheet = ss.insertSheet(name);
  if (sheet.getLastRow() === 0) {
    sheet.appendRow(headers);
    sheet.setFrozenRows(1);
    sheet.getRange(1,1,1,headers.length).setFontWeight("bold");
  }
}

function fecha_(value) {
  return value ? new Date(value) : "";
}

function calcularDistanciaKm_(route) {
  let meters = 0;
  for (let i=1; i<route.length; i++) meters += haversine_(route[i-1], route[i]);
  return Math.round((meters/1000)*100)/100;
}

function haversine_(a,b) {
  const R=6371000, rad=x=>x*Math.PI/180;
  const dLat=rad(b.lat-a.lat), dLng=rad(b.lng-a.lng);
  const lat1=rad(a.lat), lat2=rad(b.lat);
  const h=Math.sin(dLat/2)**2+
    Math.cos(lat1)*Math.cos(lat2)*Math.sin(dLng/2)**2;
  return 2*R*Math.asin(Math.sqrt(h));
}
