
const $ = (id) => document.getElementById(id);
const STORAGE_KEY = "observador_vial_pending_v2";

let watchId = null;
let points = [];
let currentTrip = null;
let map = null;
let routeLine = null;
let hazardMarker = null;
let wakeLock = null;

function getPendingTrips() {
  try { return JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]"); }
  catch { return []; }
}

function savePendingTrips(trips) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(trips));
  updateSyncStatus();
}

function updateSyncStatus(message = "") {
  const pending = getPendingTrips();
  const status = $("syncStatus");
  if (!status) return;
  status.textContent = message || (
    pending.length
      ? `${pending.length} recorrido(s) pendiente(s) de envío.`
      : "Sin recorridos pendientes."
  );
  if ($("retryBtn")) $("retryBtn").classList.toggle("hidden", pending.length === 0);
}

function distanceMeters(a, b) {
  const R = 6371000;
  const toRad = (x) => x * Math.PI / 180;
  const dLat = toRad(b.lat - a.lat);
  const dLng = toRad(b.lng - a.lng);
  const lat1 = toRad(a.lat);
  const lat2 = toRad(b.lat);
  const h = Math.sin(dLat/2)**2 + Math.cos(lat1)*Math.cos(lat2)*Math.sin(dLng/2)**2;
  return 2 * R * Math.asin(Math.sqrt(h));
}

function routeDistanceKm(route) {
  let total = 0;
  for (let i = 1; i < route.length; i++) total += distanceMeters(route[i-1], route[i]);
  return total / 1000;
}

async function requestWakeLock() {
  try {
    if ("wakeLock" in navigator) wakeLock = await navigator.wakeLock.request("screen");
  } catch (_) {}
}

async function releaseWakeLock() {
  try { if (wakeLock) await wakeLock.release(); } catch (_) {}
  wakeLock = null;
}

function validSetup() {
  const required = ["driver","vehicle","origin","destination"];
  const missing = required.find(id => !$(id).value.trim());
  if (missing) {
    $(missing).focus();
    alert("Complete todos los datos del recorrido.");
    return false;
  }
  return true;
}

$("startBtn").addEventListener("click", async () => {
  if (!validSetup()) return;
  if (!navigator.geolocation) {
    alert("Este teléfono no permite usar geolocalización desde el navegador.");
    return;
  }

  points = [];
  currentTrip = {
    id: crypto.randomUUID ? crypto.randomUUID() : String(Date.now()),
    driver: $("driver").value.trim(),
    vehicle: $("vehicle").value.trim(),
    origin: $("origin").value.trim(),
    destination: $("destination").value.trim(),
    startedAt: new Date().toISOString(),
    endedAt: null,
    route: [],
    hazards: [],
    noHazardsObserved: false
  };

  $("tripSetup").classList.add("hidden");
  $("trackingPanel").classList.remove("hidden");
  $("liveInfo").textContent = "Solicitando permiso de ubicación...";
  await requestWakeLock();

  watchId = navigator.geolocation.watchPosition(
    (pos) => {
      const p = {
        lat: pos.coords.latitude,
        lng: pos.coords.longitude,
        accuracy: Math.round(pos.coords.accuracy),
        timestamp: new Date(pos.timestamp).toISOString()
      };

      const last = points[points.length - 1];
      // Evita puntos duplicados o demasiado cercanos.
      if (!last || distanceMeters(last, p) >= 8) points.push(p);

      $("liveInfo").textContent =
        `${points.length} puntos registrados · precisión aproximada ${p.accuracy} m`;
    },
    (err) => {
      const messages = {
        1: "Permiso de GPS rechazado.",
        2: "No fue posible obtener la ubicación.",
        3: "La ubicación tardó demasiado."
      };
      $("liveInfo").textContent = messages[err.code] || "Error de ubicación.";
    },
    { enableHighAccuracy: true, maximumAge: 5000, timeout: 20000 }
  );
});

$("finishBtn").addEventListener("click", async () => {
  if (watchId !== null) navigator.geolocation.clearWatch(watchId);
  watchId = null;
  await releaseWakeLock();

  if (points.length < 2) {
    alert("No hay suficientes puntos GPS para dibujar el recorrido. Verifique que el GPS esté activo e intente nuevamente.");
    return;
  }

  currentTrip.endedAt = new Date().toISOString();
  currentTrip.route = points;
  persistCurrentTrip();

  $("trackingPanel").classList.add("hidden");
  $("resultPanel").classList.remove("hidden");
  renderTrip();
});

function persistCurrentTrip() {
  const trips = getPendingTrips();
  const index = trips.findIndex(t => t.id === currentTrip.id);
  if (index >= 0) trips[index] = currentTrip;
  else trips.push(currentTrip);
  savePendingTrips(trips);
}

function renderTrip() {
  const route = currentTrip.route;
  const latlngs = route.map(p => [p.lat, p.lng]);

  if (map) map.remove();
  map = L.map("map");
  L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", {
    maxZoom: 19,
    attribution: '&copy; OpenStreetMap'
  }).addTo(map);

  routeLine = L.polyline(latlngs, { weight: 6 }).addTo(map);
  L.marker(latlngs[0]).addTo(map).bindPopup("Inicio");
  L.marker(latlngs[latlngs.length - 1]).addTo(map).bindPopup("Final");
  map.fitBounds(routeLine.getBounds(), { padding: [20,20] });

  currentTrip.hazards.forEach(h => {
    L.marker([h.lat, h.lng]).addTo(map)
      .bindPopup(`<strong>${escapeHtml(h.type)}</strong><br>${escapeHtml(h.risk)}`);
  });

  map.on("click", (e) => {
    $("hazardLat").value = e.latlng.lat;
    $("hazardLng").value = e.latlng.lng;
    $("hazardForm").classList.remove("hidden");
    if (hazardMarker) hazardMarker.remove();
    hazardMarker = L.marker(e.latlng).addTo(map).bindPopup("Punto seleccionado").openPopup();
  });

  const start = new Date(currentTrip.startedAt);
  const end = new Date(currentTrip.endedAt);
  const minutes = Math.max(1, Math.round((end - start) / 60000));
  $("tripSummary").innerHTML = `
    <p><strong>${escapeHtml(currentTrip.origin)}</strong> → <strong>${escapeHtml(currentTrip.destination)}</strong></p>
    <p>Conductor: ${escapeHtml(currentTrip.driver)} · Vehículo: ${escapeHtml(currentTrip.vehicle)}</p>
    <p>Duración: ${minutes} min · Distancia aproximada: ${routeDistanceKm(route).toFixed(1)} km</p>
    <p>Peligros guardados: ${currentTrip.hazards.length}</p>`;
}

$("hazardForm").addEventListener("submit", (e) => {
  e.preventDefault();
  const hazard = {
    id: crypto.randomUUID ? crypto.randomUUID() : String(Date.now()),
    lat: Number($("hazardLat").value),
    lng: Number($("hazardLng").value),
    type: $("hazardType").value,
    risk: $("riskLevel").value,
    reference: $("reference").value.trim(),
    reportedAt: new Date().toISOString()
  };
  currentTrip.hazards.push(hazard);
  currentTrip.noHazardsObserved = false;
  persistCurrentTrip();
  $("hazardForm").reset();
  $("hazardForm").classList.add("hidden");
  if (hazardMarker) hazardMarker.remove();
  hazardMarker = null;
  renderTrip();
});

$("noHazardBtn").addEventListener("click", () => {
  currentTrip.noHazardsObserved = true;
  persistCurrentTrip();
  alert("Se registró que no se observaron peligros.");
});

$("newTripBtn").addEventListener("click", () => location.reload());


async function sendTripToAdministrator(trip) {
  const endpoint = APP_CONFIG?.APPS_SCRIPT_URL || "";
  if (!endpoint || endpoint.includes("PEGUE_AQUI")) {
    throw new Error("Falta configurar la URL privada de recepción.");
  }

  await fetch(endpoint, {
    method: "POST",
    mode: "no-cors",
    headers: { "Content-Type": "text/plain;charset=utf-8" },
    body: JSON.stringify({
      action: "saveTrip",
      organization: APP_CONFIG.ORGANIZATION_NAME || "",
      trip
    }),
    keepalive: true
  });
}

async function sendCurrentTrip() {
  if (!currentTrip?.endedAt) return alert("Primero debe finalizar el recorrido.");

  if (!currentTrip.noHazardsObserved && !(currentTrip.hazards || []).length) {
    if (!confirm("No se registraron peligros. ¿Desea enviar de todas formas?")) return;
  }

  const button = $("sendTripBtn");
  button.disabled = true;
  button.textContent = "Enviando...";

  try {
    await sendTripToAdministrator(currentTrip);
    savePendingTrips(getPendingTrips().filter(t => t.id !== currentTrip.id));
    updateSyncStatus("Recorrido enviado al administrador.");
    alert("Información enviada correctamente.");
    button.textContent = "Enviado";
  } catch (error) {
    persistCurrentTrip();
    updateSyncStatus(`Envío pendiente: ${error.message}`);
    alert(`No se pudo enviar. Quedó guardado para reintentar.\n\n${error.message}`);
    button.disabled = false;
    button.textContent = "Enviar recorrido al administrador";
  }
}

async function retryPendingTrips() {
  const pending = getPendingTrips();
  if (!pending.length) return;

  $("retryBtn").disabled = true;
  const remaining = [];
  let sent = 0;

  for (const trip of pending) {
    try {
      await sendTripToAdministrator(trip);
      sent++;
    } catch (_) {
      remaining.push(trip);
    }
  }

  savePendingTrips(remaining);
  $("retryBtn").disabled = false;
  alert(`${sent} enviado(s); ${remaining.length} pendiente(s).`);
}

$("sendTripBtn").addEventListener("click", sendCurrentTrip);
$("retryBtn").addEventListener("click", retryPendingTrips);

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, c => ({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"
  }[c]));
}

if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => navigator.serviceWorker.register("sw.js"));
}

document.addEventListener("visibilitychange", async () => {
  if (document.visibilityState === "visible" && watchId !== null) await requestWakeLock();
});

updateSyncStatus();

updateSyncStatus();
