# Observador Vial privado

Abra `INSTALACION_PRIVADA.md` y siga los pasos.
